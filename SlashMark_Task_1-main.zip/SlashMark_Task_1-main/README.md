# SlashMark_Task_1

Developed a basic Java application that allows users to create a task list. Users are able to add, remove, mark as done, clear and list tasks. 

Adding the task:


![image](https://github.com/Dhara0279/SlashMark_Task_1/assets/107039512/77bc5746-8a1e-4062-9874-393ba7be9b68)



Listing the task:


![image](https://github.com/Dhara0279/SlashMark_Task_1/assets/107039512/5c17aac6-cf26-4209-b0f0-feb07baa3f28)



Removing the task:


![image](https://github.com/Dhara0279/SlashMark_Task_1/assets/107039512/c344eebf-66f2-41f2-a8c9-6525ec80b9fb)



Marking as Done task:


![image](https://github.com/Dhara0279/SlashMark_Task_1/assets/107039512/42ca25aa-e211-447c-9c9e-8415ea91400e)



Clear all tasks:


![image](https://github.com/Dhara0279/SlashMark_Task_1/assets/107039512/2a28dead-bcb3-4fba-8969-41f98292b80d)




